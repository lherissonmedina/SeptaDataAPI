
<?php
    include '../database.php';
    header('Content-type: application/json');

    if ($_POST['type'] == 'near') {
        echo nearestStations($_POST['lat'], $_POST['lon'], $_POST['radius']);
    } else {
        echo json_encode(array( "error" => "No Parameters Given" ));
    }
    
    function nearestStations($lat, $lon, $radius) {
        $sql = "SELECT stations.*, stops.line_id, septa_lines.name AS line, (3959 * acos(cos(radians($lat)) * cos(radians(latitude)) * cos(radians(longitude) - radians($lon)) + sin(radians($lat)) * sin(radians(latitude)))) AS distance 
        FROM stations
        INNER JOIN stops ON stations.id=stops.station_id
        INNER JOIN septa_lines ON stops.line_id=septa_lines.id
        WHERE septa_lines.type='Rapid-Transit'
        HAVING distance < $radius
        ORDER BY distance";
        return json_encode(getData($sql));
    }
?>
