<?php
    include '../database.php';
    header('Content-type: application/json');
    
    if (isset($_POST['udid'])) {
        $values = "('".$_POST['udid']."',". $_POST['origin'].",'".$_POST['depart']."',".$_POST['destination'].", '".$_POST['arrival']."')";
        $sql = "INSERT INTO trips (id_user, id_station_origin, time_departure, id_station_destination, time_arrival) VALUES ".$values;
        echo json_encode(insertData($sql));
    } else {
        echo json_encode(array( "error" => "No Parameters Given" ));
    }
?>
