<?php
    $dbhost = $_SERVER['RDS_HOSTNAME'];
    $dbport = $_SERVER['RDS_PORT'];
    $dbname = $_SERVER['RDS_DB_NAME'];
    $username = $_SERVER['RDS_USERNAME'];
    $password = $_SERVER['RDS_PASSWORD'];
    $dsn = "mysql:host={$dbhost};port={$dbport};dbname={$dbname}";
    
    function connection() {
        global $dbhost, $username, $password, $dbname;
        $conn = new mysqli($dbhost, $username, $password, $dbname);
        
        return $conn;
    }

    function getData($sql) {
        $conn = connection();
        
        if ($conn->connect_error) {
            return array( "error" => $conn->connect_error );
        }
        
        $result = $conn->query($sql);
        $results = array();
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $results[] = $row;
            }
        }
        
        $conn->close();
        return $results;
    }

    function insertData($sql) {
        $conn = connection();
            
        if ($conn->connect_error) {
            return array( "error" => $conn->connect_error );
        }
        
        if ($conn->query($sql) === TRUE) {
            $conn->close();
            return array( "success" => "" );
        } else {
            $conn->close();
            return array( "error" => $conn->connect_error );
        }
    }
?>