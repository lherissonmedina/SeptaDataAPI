<?php
    include '../database.php';
    header('Content-type: application/json');

    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'GET':
            echo $_POST['udid'];

            if (isset($_POST['udid'])) {
                $sql = "SELECT id_user FROM users WHERE id_user = '".$_POST['udid']."'";

                echo json_encode(getData($sql));

            } else {
                echo json_encode(array( "GET: error" => "No Parameters Given" ));
            }
            break;
        case 'POST':
            if (isset($_POST['udid'])) {
                $sql = "INSERT INTO users (id_user) VALUES ('".$_POST['udid']."')";
                echo json_encode(insertData($sql));
            } else {
                echo json_encode(array( "POST: error" => "No Parameters Given" ));
            }
            break;
        case 'PUT':
            break;
        case 'DELETE':
            break;
        default:
            break;
    }

